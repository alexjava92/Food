---
sidebar_position: 3
---

# Поддерживаемые приложения

На данный момент технология Telegram Mini Apps представлена на достаточно
широком списке приложений Telegram:

- [Telegram Android](https://github.com/DrKLO/Telegram) `android`;
- [Telegram iOS](https://github.com/TelegramMessenger/Telegram-iOS) `ios`;
- [Telegram macOS](https://github.com/overtake/TelegramSwift) `macos`;
- [Telegram Desktop](https://github.com/telegramdesktop/tdesktop) `tdesktop`;
- [Telegram Web Z](https://github.com/Ajaxy/telegram-tt) `webz`.

[//]: # (FIXME)

[//]: # (В данном списке после ссылки на репозиторий проекта указан уникальный )

[//]: # (идентификатор самой платформы. Подробнее о том, зачем он нужен, рассмотрено)

[//]: # (в разделе о [параметрах запуска]&#40;launch-params/about#tgwebappplatform&#41;.)
