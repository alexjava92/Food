# Local Playground

This application can be used by developers to test the code, written in the current monorepo.
We created this playground to avoid writing the same code from one package to another, adding
`index.html` and `vite.config.ts` files.

## Usage

1. First of all just import any code from the other packages.
2. Run `pnpm run dev`.
3. Open URL from the console.