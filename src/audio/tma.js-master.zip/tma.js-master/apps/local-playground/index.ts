/*
* You can import any code from the other folders in mono-repo. For example, you could
* use this code:
*
* import { postEvent } from '../../packages/bridge/src/index.js';
*
* And test postEvent function here.
* */