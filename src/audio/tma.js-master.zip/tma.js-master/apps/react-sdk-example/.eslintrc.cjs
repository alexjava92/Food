module.exports = {
  extends: ['custom/react'],
  rules: {
    'react/react-in-jsx-scope': 'off',
  },
};
