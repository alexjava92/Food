module.exports = {
  extends: ['plugin:solid/typescript'],
  plugins: ['solid'],
  parser: '@typescript-eslint/parser',
};
