export const SESSION_STORAGE_KEY = 'telegram-mini-apps-launch-params';
