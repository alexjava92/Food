module.exports = {
  extends: ['custom/solid'],
};
