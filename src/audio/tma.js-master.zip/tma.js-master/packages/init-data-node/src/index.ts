export * from '@tma.js/init-data';

export * from './validation.js';
