module.exports = {
  base: require('./base'),
  react: require('./react'),
  solid: require('./solid'),
};