# eslint-config-custom

## 0.1.0

### Minor Changes

- 4edb39c: Add new rules to eslint config. Jest config now uses babel-jest

## 0.0.3

### Patch Changes

- 894eccb: Implement @twa.js/sdk-solid package

## 0.0.2

### Patch Changes

- 054d616: Fully rework bridge and release its first major update. Rename utilities in utils package. Make sdk components way better.

## 0.0.1

### Patch Changes

- a103e42: Optimize imports, fix minor bugs.
