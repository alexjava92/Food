module.exports = {
  extends: ['custom/base'],
};
