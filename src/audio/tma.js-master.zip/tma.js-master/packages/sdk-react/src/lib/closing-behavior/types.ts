export type { ClosingBehaviour } from '@tma.js/sdk';
