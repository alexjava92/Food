export type { Viewport } from '@tma.js/sdk';
