export type { HapticFeedback } from '@tma.js/sdk';
