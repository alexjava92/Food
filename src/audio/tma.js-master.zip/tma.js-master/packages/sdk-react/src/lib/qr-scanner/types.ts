export type { QRScanner } from '@tma.js/sdk';
