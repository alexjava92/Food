export type { Popup } from '@tma.js/sdk';
