export type { WebApp } from '@tma.js/sdk';
