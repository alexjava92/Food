export type { MainButton } from '@tma.js/sdk';
