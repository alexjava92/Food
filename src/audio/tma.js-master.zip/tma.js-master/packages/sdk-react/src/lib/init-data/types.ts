export type { InitData } from '@tma.js/sdk';
