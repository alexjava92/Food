module.exports = {
  extends: ['custom/react'],
};
