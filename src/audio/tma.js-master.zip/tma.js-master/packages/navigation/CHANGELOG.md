# @tma.js/navigation

## 0.0.7

### Patch Changes

- 3171451: Build packages in IIFE format
- Updated dependencies [3171451]
  - @tma.js/event-emitter@0.0.5
  - @tma.js/parsing@0.1.2
  - @tma.js/bridge@1.3.8
  - @tma.js/logger@0.0.4

## 0.0.6

### Patch Changes

- 3eafb45: Update package.json and fix entries for different modules.
- Updated dependencies [3eafb45]
  - @tma.js/event-emitter@0.0.4
  - @tma.js/parsing@0.1.1
  - @tma.js/bridge@1.3.7
  - @tma.js/logger@0.0.3

## 0.0.5

### Patch Changes

- Updated dependencies [bfbde56]
  - @tma.js/parsing@0.1.0
  - @tma.js/bridge@1.3.6

## 0.0.4

### Patch Changes

- Updated dependencies [d4153de]
  - @tma.js/bridge@1.3.5

## 0.0.3

### Patch Changes

- 3c6ed39: - Start using Vite instead of pure Rollup
  - Update all package.json files in all packages
  - Implement `build-utils` package to share build utilities across all packages
  - Refactor tsconfig.json files
  - Complicate examples for React and SDK
- Updated dependencies [3c6ed39]
  - @tma.js/event-emitter@0.0.3
  - @tma.js/parsing@0.0.3
  - @tma.js/bridge@1.3.4
  - @tma.js/logger@0.0.2

## 0.0.2

### Patch Changes

- Updated dependencies [654891f]
  - @tma.js/bridge@1.3.3

## 0.0.1

### Patch Changes

- f1d2932: Implement new package
- Updated dependencies [21c4632]
- Updated dependencies [5a45fb7]
  - @tma.js/event-emitter@0.0.2
  - @tma.js/parsing@0.0.2
  - @tma.js/bridge@1.3.2
  - @tma.js/logger@0.0.1
