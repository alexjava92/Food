# tsconfig

## 0.0.2

### Patch Changes

- 894eccb: Implement @twa.js/sdk-solid package

## 0.0.1

### Patch Changes

- a103e42: Optimize imports, fix minor bugs.
