module.exports = {
  extends: ['custom/base'],
  rules: {
    'no-console': 0,
  },
};
