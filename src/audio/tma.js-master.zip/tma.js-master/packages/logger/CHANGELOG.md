# @tma.js/logger

## 0.0.4

### Patch Changes

- 3171451: Build packages in IIFE format

## 0.0.3

### Patch Changes

- 3eafb45: Update package.json and fix entries for different modules.

## 0.0.2

### Patch Changes

- 3c6ed39: - Start using Vite instead of pure Rollup
  - Update all package.json files in all packages
  - Implement `build-utils` package to share build utilities across all packages
  - Refactor tsconfig.json files
  - Complicate examples for React and SDK

## 0.0.1

### Patch Changes

- 5a45fb7: Implement new package
