# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.4.0](https://github.com/Telegram-Web-Apps/sdk/compare/v0.3.3...v0.4.0) (2022-11-10)


### Features

* **packages:** add new package theme-params ([818eb41](https://github.com/Telegram-Web-Apps/sdk/commit/818eb4156607d98ab1c6c2299cb207a866b51762))






## [0.3.3](https://github.com/Telegram-Web-Apps/sdk/compare/v0.3.2...v0.3.3) (2022-11-09)

**Note:** Version bump only for package root





## [0.3.2](https://github.com/Telegram-Web-Apps/sdk/compare/v0.3.1...v0.3.2) (2022-11-09)

**Note:** Version bump only for package root






## [0.3.1](https://github.com/Telegram-Web-Apps/sdk/compare/v0.3.0...v0.3.1) (2022-11-09)

**Note:** Version bump only for package root





# [0.3.0](https://github.com/Telegram-Web-Apps/sdk/compare/v0.1.2...v0.3.0) (2022-11-09)


### Features

* **init:** start listening to window resize event. Fix parser for viewport_changed event ([6b84f01](https://github.com/Telegram-Web-Apps/sdk/commit/6b84f018cde9d75d9cce9d7de3e46e412105eee4))






# [0.2.0](https://github.com/Telegram-Web-Apps/sdk/compare/v0.1.2...v0.2.0) (2022-11-09)


### Features

* **init:** start listening to window resize event. Fix parser for viewport_changed event ([6b84f01](https://github.com/Telegram-Web-Apps/sdk/commit/6b84f018cde9d75d9cce9d7de3e46e412105eee4))





## 0.1.2 (2022-11-09)

**Note:** Version bump only for package sdk
